// Début du site personnel d'Amadou Ba - doctorant à l'ESG UQAM

import { useState } from "react";
import Image from "next/image";
import photo from "/mnt/data/unnamed.jpg";

export default function Home() {
  const [lang, setLang] = useState("fr");

  const toggleLang = () => {
    setLang(lang === "fr" ? "en" : "fr");
  };

  return (
    <main className="min-h-screen bg-white text-gray-800 font-sans p-6">
      {/* Bouton de langue */}
      <div className="flex justify-end mb-4">
        <button
          onClick={toggleLang}
          className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
        >
          {lang === "fr" ? "English" : "Français"}
        </button>
      </div>

      {/* En-tête */}
      <header className="mb-10 text-center">
        <Image
          src={photo}
          alt="Photo de Amadou Ba"
          width={150}
          height={150}
          className="rounded-full mx-auto mb-4"
        />
        <h1 className="text-4xl font-bold mb-2">Amadou Ba</h1>
        <h2 className="text-xl text-gray-600">
          {lang === "fr"
            ? "Doctorant en finance | ESG UQAM | Chaire CDPQ"
            : "PhD Candidate in Finance | ESG UQAM | CDPQ Chair"}
        </h2>
      </header>

      {/* Section Présentation */}
      <section className="mb-12">
        <h3 className="text-2xl font-semibold mb-2">
          {lang === "fr" ? "À propos" : "About"}
        </h3>
        <p className="text-base leading-7">
          {lang === "fr"
            ? "Je suis doctorant en administration à l'ESG UQAM, affilié à la Chaire CDPQ de gestion de portefeuille sous la direction du Professeur Maher Kooli. Mes recherches portent principalement sur le crowdfunding, la FinTech et le capital-risque. Mon objectif est de produire une recherche rigoureuse et applicable, avec une attention particulière portée aux marchés émergents et aux barrières structurelles à l’accès au financement."
            : "I am a PhD candidate in administration at ESG UQAM, affiliated with the CDPQ Chair in Portfolio Management under the supervision of Professor Maher Kooli. My research focuses on crowdfunding, FinTech, and venture capital. I aim to produce rigorous and applicable research, with special attention to emerging markets and structural barriers to financial access."}
        </p>
      </section>

      {/* Section Recherches */}
      <section className="mb-12">
        <h3 className="text-2xl font-semibold mb-2">
          {lang === "fr" ? "Recherches" : "Research"}
        </h3>
        <ul className="list-disc list-inside text-base leading-7">
          {lang === "fr" ? (
            <>
              <li>Déterminants de la performance du crowdfunding en Afrique</li>
              <li>Théorie du signal et plateformes numériques de financement participatif</li>
              <li>Risques géopolitiques, normes culturelles et performance des campagnes</li>
              <li>Microfinance participative : monitoring, genre et inclusion financière</li>
            </>
          ) : (
            <>
              <li>Determinants of crowdfunding performance in Africa</li>
              <li>Signaling theory and digital crowdfunding platforms</li>
              <li>Geopolitical risk, cultural norms, and campaign performance</li>
              <li>Participatory microfinance: monitoring, gender, and financial inclusion</li>
            </>
          )}
        </ul>
      </section>

      {/* Section Publications */}
      <section className="mb-12">
        <h3 className="text-2xl font-semibold mb-2">
          {lang === "fr" ? "Publications & travaux en cours" : "Publications & Ongoing Work"}
        </h3>
        <ul className="list-disc list-inside text-base leading-7">
          <li>
            {lang === "fr"
              ? "Amadou Ba, Mohamed Lamine Mbengue (2021). Les déterminants de la structure financière : cas des sociétés cotées à la Bourse Régionale des Valeurs Mobilières (BRVM), La Revue du financier, vol. 44, no 247, novembre-décembre."
              : "Amadou Ba, Mohamed Lamine Mbengue (2021). Determinants of Capital Structure: Case of Listed Companies on the West African Regional Stock Exchange (BRVM), La Revue du financier, vol. 44, no 247, Nov-Dec."}
          </li>
          <li>
            {lang === "fr"
              ? "Articles en cours de soumission et documents de travail à venir."
              : "Articles under review and working papers coming soon."}
          </li>
        </ul>
      </section>

      {/* Section CV */}
      <section className="mb-12">
        <h3 className="text-2xl font-semibold mb-2">CV</h3>
        <a
          href="#"
          className="text-blue-600 underline hover:text-blue-800"
          download
        >
          {lang === "fr" ? "Télécharger mon CV (PDF)" : "Download my CV (PDF)"}
        </a>
      </section>

      {/* Section Contact */}
      <section className="mb-12">
        <h3 className="text-2xl font-semibold mb-2">
          {lang === "fr" ? "Contact" : "Contact"}
        </h3>
        <p className="text-base leading-7">
          📧 amadou.ba@email.com<br />
          🔗 <a href="https://scholar.google.com" className="text-blue-600 underline hover:text-blue-800" target="_blank">Google Scholar</a><br />
          🔗 <a href="https://linkedin.com" className="text-blue-600 underline hover:text-blue-800" target="_blank">LinkedIn</a>
        </p>
      </section>
    </main>
  );
}
